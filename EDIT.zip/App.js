
import Personlist from './Personlist';
import Personinput from './Personinput';

function App() {
  return (
    <div className="App">
      <Personinput/>
      <Personlist/>
    </div>
  );
}

export default App;
